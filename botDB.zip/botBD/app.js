angular.module('rocketbotApp',[])
.controller('MainController', function($timeout, $scope, $http){

    $timeout(function () {
        $(".loader-wrap ").fadeOut(10);
    }, 100);

    $scope.nameBot = nameBot;
    $scope.res_id = res_id;
    $scope.data = data;
    $scope.versions = versions;
    $scope.my_version = versions.length
    //console.log('versions', $scope.versions)
    //console.log('versions', $scope.my_version)


    $scope.changed = function(index){
        //console.log('data',$scope.data.model);
        var res = $scope.data.model.split("||");
        $scope.robot = res[0]
        var index = res[1]
        index = index.trim();
        new_id = parseInt($scope.res_id) + 1
        $scope.actual_version = res[2]

        var formData = new FormData();
        formData.append('robot',$scope.robot)
        formData.append('new_id',new_id)
        formData.append('name_bot',$scope.nameBot)
        //console.log($scope.robot)

        $scope.showAlert = (event) => {
            event.preventDefault();
            let result = confirm('You really want to update '+ $scope.nameBot + ' robot to' + $scope.actual_version + ' version?');
            if(result) {
               fetch("/botBD/insert",{
                method: 'POST', // or 'PUT'
                body: formData, // data can be `string` or {object}!
                });

               parent.location.reload()
            }else{
                location.reload()
            }




        }











    }




    
})


